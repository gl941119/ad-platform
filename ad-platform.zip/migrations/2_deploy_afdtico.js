var AFDTICO = artifacts.require("./AFDTICO.sol");

module.exports = function(deployer) {
  deployer.deploy(AFDTICO);
};