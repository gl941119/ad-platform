import Utils from '../utils/util';
let util = new Utils();
export default {
    dateFormat: util.dateFormat.bind(util),
}