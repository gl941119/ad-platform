export default {
	country:[{
		value:'Afghanistan',
		label:'Afghanistan'
	},{
		value:'Albania',
		label:'Albania'
	},{
		value:'Algeria',
		label:'Algeria'
	},{
		value:'Andorra',
		label:'Andorra'
	},{
		value:'Angola',
		label:'Angola'
	},{
		value:'Anguilla',
		label:'Anguilla'
	},{
		value:'Antigua and Barbuda',
		label:'Antigua and Barbuda'
	},{
		value:'Argentina',
		label:'Argentina'
	},{
		value:'Armenia',
		label:'Armenia'
	},{
		value:'Ascension',
		label:'Ascension'
	},{
		value:'Australia ',
		label:'Australia'
	},{
		value:'Austria',
		label:'Austria'
	},{
		value:'Azerbaijan',
		label:'Azerbaijan'
	},{
		value:'Bahamas',
		label:'Bahamas'
	},{
		value:'Bahrain',
		label:'Bahrain'
	},{
		value:'Bangladesh',
		label:'Bangladesh'
	},{
		value:'Barbados',
		label:'Barbados'
	},{
		value:'Belarus',
		label:'Belarus'
	},{
		value:'Belgium',
		label:'Belgium'
	},{
		value:'Belize',
		label:'Belize'
	},{
		value:'Benin',
		label:'Benin'
	},{
		value:'Bermuda Is.',
		label:'Bermuda Is.'
	},{
		value:'Bolivia',
		label:'Bolivia'
	},{
		value:'Botswana',
		label:'Botswana'
	},{
		value:'Brazil',
		label:'Brazil'
	},{
		value:'Brunei',
		label:'Brunei'
	},{
		value:'Bulgaria',
		label:'Bulgaria'
	},{
		value:'Burkina-faso',
		label:'Burkina-faso'
	},{
		value:'Burma',
		label:'Burma'
	},{
		value:'Burundi',
		label:'Burundi'
	},{
		value:'Cameroon',
		label:'Cameroon'
	},{
		value:'Canada',
		label:'Canada'
	},{
		value:'Cayman Is.',
		label:'Cayman Is.'
	},{
		value:'Central African Republic',
		label:'Central African Republic'
	},{
		value:'Chad',
		label:'Chad'
	},{
		value:'Chile',
		label:'Chile'
	},{
		value:'China',
		label:'China'
	},{
		value:'Colombia',
		label:'Colombia'
	},{
		value:'Congo',
		label:'Congo'
	},{
		value:'Cook Is.',
		label:'Cook Is.'
	},{
		value:'Costa Rica',
		label:'Costa Rica'
	},{
		value:'Cuba',
		label:'Cuba'
	},{
		value:'Cyprus',
		label:'Cyprus'
	},{
		value:'Czech Republic',
		label:'Czech Republic'
	},{
		value:'Denmark',
		label:'Denmark'
	},{
		value:'Djibouti',
		label:'Djibouti'
	},{
		value:'Dominica Rep.',
		label:'Dominica Rep.'
	},{
		value:'Ecuador',
		label:'Ecuador'
	},{
		value:'Egypt',
		label:'Egypt'
	},{
		value:'EI Salvador',
		label:'EI Salvador'
	},{
		value:'Estonia',
		label:'Estonia'
	},{
		value:'Ethiopia',
		label:'Ethiopia'
	},{
		value:'Fiji',
		label:'Fiji'
	},{
		value:'Finland',
		label:'Finland'
	},{
		value:'France',
		label:'France'
	},{
		value:'French Guiana',
		label:'French Guiana'
	},{
		value:'Gabon',
		label:'Gabon '
	},{
		value:'Gambia',
		label:'Gambia'
	},{
		value:'Georgia',
		label:'Georgia'
	},{
		value:'Germany',
		label:'Germany'
	},{
		value:'Ghana',
		label:'Ghana'
	},{
		value:'Gibraltar',
		label:'Gibraltar'
	},{
		value:'Greece',
		label:'Greece'
	},{
		value:'Grenada',
		label:'Grenada'
	},{
		value:'Guam',
		label:'Guam'
	},{
		value:'Guatemala',
		label:'Guatemala'
	},{
		value:'Guinea',
		label:'Guinea'
	},{
		value:'Guyana',
		label:'Guyana'
	},{
		value:'Haiti',
		label:'Haiti'
	},{
		value:'Honduras',
		label:'Honduras'
	},{
		value:'Hong Kong',
		label:'Hong Kong'
	},{
		value:'Hungary',
		label:'Hungary'
	},{
		value:'Iceland',
		label:'Iceland'
	},{
		value:'India',
		label:'India'
	},{
		value:'Indonesia',
		label:'Indonesia'
	},{
		value:'Iran',
		label:'Iran'
	},{
		value:'Iraq',
		label:'Iraq'
	},{
		value:'Ireland',
		label:'Ireland'
	},{
		value:'Israel',
		label:'Israel'
	},{
		value:'Italy',
		label:'Italy'
	},{
		value:'Ivory Coast',
		label:'Ivory Coast'
	},{
		value:'Jamaica',
		label:'Jamaica'
	},{
		value:'Japan',
		label:'Japan'
	},{
		value:'Jordan',
		label:'Jordan'
	},{
		value:'Kampuchea (Cambodia )',
		label:'Kampuchea (Cambodia )'
	},{
		value:'Kazakstan',
		label:'Kazakstan'
	},{
		value:'Kenya',
		label:'Kenya'
	},{
		value:'Korea',
		label:'Korea'
	},{
		value:'Kuwait',
		label:'Kuwait'
	},{
		value:'Kyrgyzstan',
		label:'Kyrgyzstan'
	},{
		value:'Laos',
		label:'Laos'
	},{
		value:'Latvia',
		label:'Latvia'
	},{
		value:'Lebanon',
		label:'Lebanon'
	},{
		value:'Lesotho',
		label:'Lesotho'
	},{
		value:'Liberia',
		label:'Liberia'
	},{
		value:'Libya',
		label:'Libya'
	},{
		value:'Liechtenstein',
		label:'Liechtenstein'
	},{
		value:'Lithuania',
		label:'Lithuania'
	},{
		value:'Luxembourg',
		label:'Luxembourg'
	},{
		value:'Macao',
		label:'Macao'
	},{
		value:'Madagascar',
		label:'Madagascar'
	},{
		value:'Malawi',
		label:'Malawi'
	},{
		value:'Malaysia',
		label:'Malaysia'
	},{
		value:'Maldives',
		label:'Maldives'
	},{
		value:'Mali',
		label:'Mali'
	},{
		value:'Malta',
		label:'Malta'
	},{
		value:'Mariana Is',
		label:'Mariana Is'
	},{
		value:'Martinique',
		label:'Martinique'
	},{
		value:'Mauritius',
		label:'Mauritius'
	},{
		value:'Mexico',
		label:'Mexico'
	},{
		value:'Moldova, Republic of',
		label:'Moldova, Republic of'
	},{
		value:'Monaco',
		label:'Monaco'
	},{
		value:'Mongolia',
		label:'Mongolia'
	},{
		value:'Montserrat Is',
		label:'Montserrat Is'
	},{
		value:'Morocco',
		label:'Morocco'
	},{
		value:'Mozambique',
		label:'Mozambique'
	},{
		value:'Namibia',
		label:'Namibia'
	},{
		value:'Nauru',
		label:'Nauru'
	},{
		value:'Nepal',
		label:'Nepal'
	},{
		value:'Netheriands Antilles',
		label:'Netheriands Antilles'
	},{
		value:'Netherlands',
		label:'Netherlands'
	},{
		value:'New Zealand',
		label:'New Zealand'
	},{
		value:'Nicaragua',
		label:'Nicaragua'
	},{
		value:'Niger',
		label:'Niger'
	},{
		value:'Nigeria',
		label:'Nigeria'
	},{
		value:'North Korea',
		label:'North Korea'
	},{
		value:'Norway',
		label:'Norway'
	},{
		value:'Oman',
		label:'Oman'
	},{
		value:'Pakistan',
		label:'Pakistan'
	},{
		value:'Panama',
		label:'Panama'
	},{
		value:'Papua New Cuinea',
		label:'Papua New Cuinea'
	},{
		value:'Paraguay',
		label:'Paraguay'
	},{
		value:'Peru',
		label:'Peru'
	},{
		value:'Philippines',
		label:'Philippines'
	},{
		value:'Poland',
		label:'Poland'
	},{
		value:'French Polynesia',
		label:'French Polynesia'
	},{
		value:'Portugal',
		label:'Portugal'
	},{
		value:'Puerto Rico',
		label:'Puerto Rico'
	},{
		value:'Qatar',
		label:'Qatar'
	},{
		value:'Reunion',
		label:'Reunion'
	},{
		value:'Romania',
		label:'Romania'
	},{
		value:'Russia',
		label:'Russia'
	},{
		value:'Saint Lueia',
		label:'Saint Lueia'
	},{
		value:'Saint Vincent',
		label:'Saint Vincent'
	},{
		value:'Samoa Eastern',
		label:'Samoa Eastern'
	},{
		value:'Samoa Western',
		label:'Samoa Western'
	},{
		value:'San Marino',
		label:'San Marino'
	},{
		value:'Sao Tome and Principe',
		label:'Sao Tome and Principe'
	},{
		value:'Saudi Arabia',
		label:'Saudi Arabia'
	},{
		value:'Senegal',
		label:'Senegal'
	},{
		value:'Seychelles',
		label:'Seychelles'
	},{
		value:'Sierra Leone',
		label:'Sierra Leone'
	},{
		value:'Singapore',
		label:'Singapore'
	},{
		value:'Slovakia',
		label:'Slovakia'
	},{
		value:'Slovenia',
		label:'Slovenia'
	},{
		value:'Solomon Is',
		label:'Solomon Is'
	},{
		value:'Somali',
		label:'Somali'
	},{
		value:'South Africa',
		label:'South Africa'
	},{
		value:'Spain',
		label:'Spain'
	},{
		value:'Sri Lanka',
		label:'Sri Lanka'
	},{
		value:'St.Vincent',
		label:'St.Vincent'
	},{
		value:'Sudan',
		label:'Sudan'
	},{
		value:'Suriname',
		label:'Suriname'
	},{
		value:'Swaziland',
		label:'Swaziland'
	},{
		value:'Sweden',
		label:'Sweden'
	},{
		value:'Switzerland',
		label:'Switzerland'
	},{
		value:'Syria',
		label:'Syria'
	},{
		value:'Taiwan',
		label:'Taiwan'
	},{
		value:'Tajikstan',
		label:'Tajikstan'
	},{
		value:'Tanzania',
		label:'Tanzania'
	},{
		value:'Thailand',
		label:'Thailand'
	},{
		value:'Togo',
		label:'Togo'
	},{
		value:'Tonga',
		label:'Tonga'
	},{
		value:'Trinidad and Tobago',
		label:'Trinidad and Tobago'
	},{
		value:'Tunisia',
		label:'Tunisia'
	},{
		value:'Turkey',
		label:'Turkey'
	},{
		value:'Turkmenistan',
		label:'Turkmenistan'
	},{
		value:'Uganda',
		label:'Uganda'
	},{
		value:'Ukraine',
		label:'Ukraine'
	},{
		value:'United Arab Emirates',
		label:'United Arab Emirates'
	},{
		value:'United Kiongdom',
		label:'United Kiongdom'
	},{
		value:'United States of America',
		label:'United States of America'
	},{
		value:'Uruguay',
		label:'Uruguay'
	},{
		value:'Uzbekistan',
		label:'Uzbekistan'
	},{
		value:'Venezuela',
		label:'Venezuela'
	},{
		value:'Vietnam',
		label:'Vietnam'
	},{
		value:'Yemen',
		label:'Yemen'
	},{
		value:'Yugoslavia',
		label:'Yugoslavia'
	},{
		value:'Zimbabwe',
		label:'Zimbabwe'
	},{
		value:'Zaire',
		label:'Zaire'
	},{
		value:'Zambia',
		label:'Zambia'
	}]
}
