import en from './en';
import zh from './zh';
import ja from './ja';
import ko from './ko';
export default {
    EN:en,
    zh:zh,
    ja:ja,
    ko:ko,
}
