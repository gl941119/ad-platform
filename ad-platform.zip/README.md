## ad-platform

> A Vue.js project

### Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8000
npm start
```


### build for production with minification
```bash
# build dependencies
npm run dll

# dist
npm run build
```

# build for production and view the bundle analyzer report
```bash
# analyzer
npm run build --report

```